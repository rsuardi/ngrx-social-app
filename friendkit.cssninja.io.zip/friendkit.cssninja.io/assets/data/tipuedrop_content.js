var tipuedrop = {
    "pages": [
        {
            "title": "Jenna Davis",
            "thumb": "assets/img/avatars/jenna.png",
            "text": "<small>Influencer, PARIS</small>",
            "url": "/profile"
        },
        {
            "title": "Dan Walker",
            "thumb": "assets/img/avatars/dan.jpg",
            "text": "<small>Developer, NY</small>",
            "url": "/profile"
        },
        {
            "title": "Stella Bergmann",
            "thumb": "assets/img/avatars/stella.jpg",
            "text": "<small>Student, BERLIN</small>",
            "url": "/profile"
        },
        {
            "title": "Daniel Wellington",
            "thumb": "assets/img/avatars/daniel.jpg",
            "text": "<small>Teacher, LONDON</small>",
            "url": "/profile"
        },
        {
            "title": "David Kim",
            "thumb": "assets/img/avatars/david.jpg",
            "text": "<small>Developer, LA</small>",
            "url": "/profile"
        },
        {
            "title": "Edward Mayers",
            "thumb": "assets/img/avatars/edward.jpeg",
            "text": "<small>Doctor, DUBLIN</small>",
            "url": "/profile"
        },
        {
            "title": "Elise Walker",
            "thumb": "assets/img/avatars/elise.jpg",
            "text": "<small>Influencer, LONDON</small>",
            "url": "/profile"
        },
        {
            "title": "Milly Augustine",
            "thumb": "assets/img/avatars/milly.jpg",
            "text": "<small>Lawyer, ROME</small>",
            "url": "/profile"
        },
        {
            "title": "Bobby Brown",
            "thumb": "assets/img/avatars/bobby.jpg",
            "text": "<small>Designer, PARIS</small>",
            "url": "/profile"
        },
        {
            "title": "Nelly Schwartz",
            "thumb": "assets/img/avatars/nelly.png",
            "text": "<small>CFO, MELBOURNE</small>",
            "url": "/profile"
        },
        {
            "title": "Lana Henrikssen",
            "thumb": "assets/img/avatars/lana.jpeg",
            "text": "<small>Student, HELSINKI</small>",
            "url": "/profile"
        },
        {
            "title": "Gaelle Morris",
            "thumb": "assets/img/avatars/gaelle.jpeg",
            "text": "<small>Merchant, Lyon</small>",
            "url": "/profile"
        },
        {
            "title": "Mike Lasalle",
            "thumb": "assets/img/avatars/mike.jpg",
            "text": "<small>Businessman, TORONTO</small>",
            "url": "/profile"
        },
        {
            "title": "Rolf Krupp",
            "thumb": "assets/img/avatars/rolf.jpg",
            "text": "<small>Accountant, BERLIN</small>",
            "url": "/profile"
        },
        {
            "title": "Android Studio",
            "thumb": "assets/img/icons/logos/android.svg",
            "text": "<small>Technology</small>",
            "url": "/profile"
        },
        {
            "title": "Angular",
            "thumb": "assets/img/icons/logos/angular.svg",
            "text": "<small>Technology</small>",
            "url": "/profile"
        },
        {
            "title": "Domino's Pizza",
            "thumb": "assets/img/icons/logos/domino.jpg",
            "text": "<small>Pizza & Fast Food</small>",
            "url": "/profile"
        },
        {
            "title": "IMDB",
            "thumb": "assets/img/icons/logos/imdb.png",
            "text": "<small>Movies / Entertainment</small>",
            "url": "/profile"
        },
        {
            "title": "Vuejs",
            "thumb": "assets/img/icons/logos/vuejs.svg",
            "text": "<small>Technology</small>",
            "url": "/profile"
        },
        {
            "title": "Reactjs",
            "thumb": "assets/img/icons/logos/reactjs.svg",
            "text": "<small>Technology</small>",
            "url": "/profile"
        },
        {
            "title": "Photoshop",
            "thumb": "assets/img/icons/logos/photoshop.svg",
            "text": "<small>Design</small>",
            "url": "/profile"
        },
        {
            "title": "WordPress",
            "thumb": "assets/img/icons/logos/wordpress.svg",
            "text": "<small>Technology</small>",
            "url": "/profile"
        }
    ]
};
